from __future__ import print_function

import os
import sys
import fnmatch
import random
import numpy as np
import traceback
import tensorflow as tf
import pdb

import logging
 
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)

TRAIN_DIRECTORY = "./data_train"
VALIDATION_DIRECTORY = "./data_validation"

BATCH_SIZE = 50
IMAGE_SIZE = 20
FEATURE_PLANES = 8
FILTERS = 128
HIDDEN = 12800
NUM_STEPS = 2000010
LABEL_SIZE = 30433
PLAYER_PIECES = []
TF_TRAIN_DATASET = None
TF_TRAIN_LABELS = None
TF_TRAIN_PREDICTION = None
LOGDIR = None
LOSS = None
SESS = None
OPTIMIZER = None
SAVER = None

PIECE_MAPPING = [
    ["101", "a"],
    ["201", "b"],
    ["301", "c"],
    ["302", "d"],
    ["401", "e"],
    ["402", "f"],
    ["403", "g"],
    ["404", "h"],
    ["405", "i"],
    ["501", "j"],
    ["502", "k"],
    ["503", "l"],
    ["504", "m"],
    ["505", "n"],
    ["506", "o"],
    ["507", "p"],
    ["508", "q"],
    ["509", "r"],
    ["510", "s"],
    ["511", "t"],
    ["512", "u"]
]

PIECES = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q", "r","s","t","u"]

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial)


def bias_variable(shape):
    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial)


def conv2d(x, W, stride):
    return tf.nn.conv2d(x, W, strides=[1, stride, stride, 1], padding="SAME")


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def model(data):
    # network weights
    W_conv1 = weight_variable([IMAGE_SIZE, IMAGE_SIZE, FEATURE_PLANES, FILTERS])
    b_conv1 = bias_variable([FILTERS])

    W_conv2 = weight_variable([5, 5, FILTERS, FILTERS])
    b_conv2 = bias_variable([FILTERS])

    W_conv3 = weight_variable([3, 3, FILTERS, FILTERS])
    b_conv3 = bias_variable([FILTERS])

    W_fc1 = weight_variable([HIDDEN, HIDDEN])
    b_fc1 = bias_variable([HIDDEN])

    W_fc2 = weight_variable([HIDDEN, LABEL_SIZE])
    b_fc2 = bias_variable([LABEL_SIZE])

    # hidden layers
    h_conv1 = tf.nn.relu(conv2d(data, W_conv1, 1) + b_conv1)
    h_conv2 = tf.nn.relu(conv2d(h_conv1, W_conv2, 1) + b_conv2)
    h_conv3 = tf.nn.relu(conv2d(h_conv2, W_conv3, 1) + b_conv3)
    h_pool3 = max_pool_2x2(h_conv3)
    h_flat = tf.reshape(h_pool3, [-1, HIDDEN])
    h_fc1 = tf.nn.relu(tf.matmul(h_flat, W_fc1) + b_fc1)

    # readout layer
    readout = tf.matmul(h_fc1, W_fc2) + b_fc2
    return readout

def init_tf():
    global TF_TRAIN_PREDICTION
    global TF_TRAIN_DATASET
    global TF_TRAIN_LABELS
    global LOGDIR
    global LOSS
    global SESS
    global OPTIMIZER
    global SAVER
    LOGDIR = "logdir"

    if not os.path.isdir(LOGDIR):
        os.makedirs(LOGDIR)

    TF_TRAIN_DATASET = tf.placeholder(tf.float32,
                                  shape=(BATCH_SIZE,
                                  IMAGE_SIZE,
                                  IMAGE_SIZE,
                                  FEATURE_PLANES))
    TF_TRAIN_LABELS = tf.placeholder(tf.float32,
                                     shape=(BATCH_SIZE,
                                     LABEL_SIZE))

    # Training computation.
    logits = model(TF_TRAIN_DATASET)
    LOSS = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits(logits = logits, labels = TF_TRAIN_LABELS))

    # Optimizer.
    OPTIMIZER = tf.train.GradientDescentOptimizer(0.05).minimize(LOSS)

    # Predictions for the training, validation, and test data.
    TF_TRAIN_PREDICTION = tf.nn.softmax(logits)

    # Initialize session all variables
    SESS = tf.InteractiveSession()
    SAVER = tf.train.Saver()
    SESS.run(tf.initialize_all_variables())
    checkpoint = tf.train.get_checkpoint_state(LOGDIR)
    if checkpoint and checkpoint.model_checkpoint_path:
        SAVER.restore(SESS, checkpoint.model_checkpoint_path)
        print ("Successfully loaded:", checkpoint.model_checkpoint_path)

def find_files(directory, pattern):
    '''Recursively finds all files matching the pattern.'''
    files = []
    for root, dirnames, filenames in os.walk(directory):
        for filename in fnmatch.filter(filenames, pattern):
            files.append(os.path.join(root, filename))
    return files

def _read_text(filename, batch_size):
    with open(filename) as f:
        return random.sample(f.readlines(), batch_size)


def generate_batch(batch_size, directory, pattern):
    '''Generator that yields text raw from the directory.'''
    files = find_files(directory, pattern)
    random.shuffle(files)
    for filename in files:
        text = _read_text(filename, batch_size)
        yield text


def reformat(datas):
    games = list(datas)
    for game in games[0]:
        game_arr = game.split(" ")
        board_state = (game_arr[0]).replace("\\","")
        label_state = int((game_arr[7]).replace("\n", ""))
        first_step = int(game_arr[1])
        no = int(game_arr[2])
        base_point = (game_arr[5])
        new_point = (game_arr[6])

        score = int(int(game_arr[3]) > 0)
        label = np.zeros(LABEL_SIZE)
        label[label_state] = 1.

        plane_list = []
        plane_list.append(np.reshape([int(-1 if not val == "0" else 0) for val in board_state],(IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.reshape([int(1 if not val == "0" else 0) for val in board_state],(IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), first_step, dtype=int))
        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), score, dtype=int))
        plane_list.append(np.reshape([((ord(val) - 96) / 10. if not val == "1" and not val == "0" else 0) for val in board_state], (IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.reshape([int(val == "1") for val in board_state], (IMAGE_SIZE, IMAGE_SIZE)))

        plane_hot_points = np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=int)

        x,y = base_point.split(",")
        plane_hot_points[int(y)][int(x)] = 1

        x,y = new_point.split(",")
        plane_hot_points[int(y)][int(x)] = 1        

        plane_list.append(plane_hot_points)

        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), no / 84))

        planes = np.vstack(tuple(plane_list))
        planes = np.reshape(planes, (IMAGE_SIZE, IMAGE_SIZE, FEATURE_PLANES))
        yield (planes, label)


def accuracy(predictions, labels):
    return (100.0 * np.sum(np.argmax(predictions, 1) == np.argmax(labels, 1))
          / predictions.shape[0])


def main():
    global TF_TRAIN_PREDICTION
    global TF_TRAIN_DATASET
    global TF_TRAIN_LABELS
    global LOGDIR
    global LOSS
    global SESS
    global OPTIMIZER
    global SAVER

    init_tf()
    print('Training...')

    for step in range(NUM_STEPS):
        try:
            train_batch = generate_batch(BATCH_SIZE, TRAIN_DIRECTORY, "*.dat")
            train_dataset = reformat(train_batch)
            batch_data = []
            batch_labels = []
            for plane, label in train_dataset:
                batch_data.append(plane)
                batch_labels.append(label)
            feed_dict = {TF_TRAIN_DATASET: batch_data, TF_TRAIN_LABELS: batch_labels}
            _, l, predictions = SESS.run(
              [OPTIMIZER, LOSS, TF_TRAIN_PREDICTION], feed_dict=feed_dict)
            if (step % 100 == 0):
                print('Minibatch loss at step %d: %f' % (step, l))
                print('Minibatch accuracy: %.1f%%' % accuracy(predictions, batch_labels))
                # We check accuracy with the validation data set
                validation_batch = generate_batch(BATCH_SIZE, VALIDATION_DIRECTORY, "*.dat")
                validation_dataset = reformat(validation_batch)
                batch_valid_data = []
                batch_valid_labels = []
                for plane, label in validation_dataset:
                    batch_valid_data.append(plane)
                    batch_valid_labels.append(label)
                feed_dict_valid = {TF_TRAIN_DATASET: batch_valid_data}
                predictions_valid = SESS.run([TF_TRAIN_PREDICTION], feed_dict=feed_dict_valid)
                print('Validation accuracy: %.1f%%' % accuracy(
                      predictions_valid[0], batch_valid_labels))
            # save progress every 500 iterations
            if step % 500 == 0 and step > 0:
                SAVER.save(SESS, 'logdir/chess-dqn', global_step=step)
        except:
            exc_type , exc_value, exc_traceback = sys.exc_info()
            print(traceback.format_exception(exc_type, exc_value, exc_traceback))
            pass


if __name__ == '__main__':
    main()
