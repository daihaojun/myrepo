import os
import sys
import json
import pdb
import fnmatch

import numpy as np

from glob import glob

PIECE_MAPPING = [
	["101", "a"],
	["201", "b"],
	["301", "c"],
	["302", "d"],
	["401", "e"],
	["402", "f"],
	["403", "g"],
	["404", "h"],
	["405", "i"],
	["501", "j"],
	["502", "k"],
	["503", "l"],
	["504", "m"],
	["505", "n"],
	["506", "o"],
	["507", "p"],
	["508", "q"],
	["509", "r"],
	["510", "s"],
	["511", "t"],
	["512", "u"]
]

PIECES = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u"]

HEADER = "var msg = "

IMAGE_SIZE = 20
LABELS = []
LINES  = []
BATCH = 0
LABELS_DIRECTORY = "./labels"

def get_piece(id):
	for piece_map in PIECE_MAPPING:
		if piece_map[0] == str(id):
			return piece_map[1]

	raise Exception("err")

def find_dataset(dataset_folder):
	result = [y for x in os.walk(dataset_folder) for y in glob(os.path.join(x[0],"*.txt"))]
	return result

def find_files(directory, pattern):
	files = []
	for root, dirnames, filenames in os.walk(directory):
		for filename in fnmatch.filter(filenames, pattern):
			files.append(os.path.join(root, filename))
	return files

def load_labels():
	global LABELS
	files = find_files(LABELS_DIRECTORY, "*.txt")
	for filename in files:
		with open(filename) as f:
 			lines = f.readlines()
 			for label in lines:
 				if(label != " " and label != "\n"):
 					LABELS.append(label.replace("\n","").replace("\r",""))
 	LABEL_SIZE = len(LABELS)

def process_one_file(file_path):
	global LABELS
	global LINES
	global BATCH
	with open(file_path, "r") as content_file:
		content = content_file.read()
		if content.startswith(HEADER):
			content = content[len(HEADER):]
			if content.endswith(";"):
				content = content[:-1]
			game = json.loads(content)
			if len(game) < 3:
				return

			players = game[0]
			score = game[-1]
			result = {}
			team1_score = 0
			team2_score = 0

			for i in range(0, 2):
				team = score["msg_data"]["teams"][i]

				if team["players"][0]["player_id"] == 2 or team["players"][0]["player_id"] == 4:
					team2_score = team["score"]
				else:
					team1_score = team["score"]

			boards = [
				np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=str),
				np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=str),
				np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=str),
				np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=str)
			]

			for index, item in enumerate(game):
				if not item["msg_name"] == "notification":
					continue

				chessman = item["msg_data"]["chessman"]
				player_id = item["msg_data"]["player_id"]
				no = item["msg_data"]["hand"]["no"]

				if "cause" in chessman:
					if chessman["cause"] == "chessman_illegal":
						return
				else:
					rotated_board = np.copy(boards[player_id - 1])
					if player_id >= 2:
						rotated_board = np.rot90(rotated_board, player_id - 1)

					oneline_board = "\\".join(''.join(str(x) for x in y) for y in rotated_board)

					piece = get_piece(chessman["id"])

					step_cover = np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype = int)

					for sq in chessman["squareness"]:
						y = 19 - sq["y"]
						x = sq["x"]

						step_cover[y][x] = 1

					if player_id >= 2:
						step_cover = np.rot90(step_cover, player_id - 1)

					points = np.argwhere(step_cover > 0)
					pos = []
					for point in points:
						pos.append([point[1],19 - point[0]])

					pos = sorted(pos, key = lambda k: [k[0], k[1]])
					arr1 = []
					for a in pos:
						arr1.append("%s,%s" % (a[0], a[1]))
					label = "%s %s" % (piece, " ".join(arr1))
					label_found = False
					for idx, val in enumerate(LABELS):
						if label == val:
							label = str(idx)
							label_found = True
							break

					if not label_found:
						print("ERROR:")
						print(file_path)
						print(label)
						print(json.dumps(item))
						print("")
						continue

					for sq in chessman["squareness"]:
						y = 19 - sq["y"]
						x = sq["x"]

						for idx, val in enumerate(boards):
							if idx == player_id - 1:
								val[y][x] = piece
							else:
								val[y][x] = "1"

					base_point = "0,0"
					new_point = "0,0"
					for p in points:
						x = p[1]
						y = p[0]
						neighbors = [[x+1,y+1],[x-1,y-1],[x+1,y-1],[x-1,y+1]]
						for neighbor in neighbors:
							if neighbor[0] >= 0 and neighbor[0] <= 19 and neighbor[1] >= 0 and neighbor[1] <= 19:
								if rotated_board[neighbor[1]][neighbor[0]] in PIECES:
									base_point = "%s,%s" % (str(neighbor[0]),str(19 - neighbor[1]))
									new_point = "%s,%s" % (str(x), str(19 - y))

					if player_id == 1 or player_id == 3:
						win_lose = int(team1_score > team2_score)
					else:
						win_lose = int(team1_score < team2_score)

					first_step = int(player_id == no)
					line = "%s %s %s %s %s %s %s %s" % (oneline_board, first_step, no, win_lose, piece, base_point, new_point, label)
					LINES.append(line)
					if len(LINES) >= 1000:
						with open("/home/daihaojun/ai/code/data_train/%s.dat" % str(BATCH), "w") as data_file:
							data_file.write("\n".join(LINES))
						LINES = []
						BATCH = BATCH + 1


def load_data():
	global LABELS
	global LINES
	global BATCH
	load_labels()

	dataset_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'datasets')
	dataset_files = find_dataset(dataset_path)
	print "# of dataset files:%s" % len(dataset_files)
	val = 0
	for f in dataset_files:
		val = val + 1
		
		try:
			process_one_file(f)
		except:
			print(f)
			pass	

	if len(LINES) >= 1:
		with open("/home/daihaojun/ai/code/data_train/%s.dat" % str(BATCH), "w") as data_file:
			data_file.write("\n".join(LINES))
		LINES = []
		BATCH = BATCH + 1

if __name__ == "__main__":
	load_data()