from __future__ import print_function

import os
import re
import sys
import fnmatch
import random
import numpy as np
import traceback
import tensorflow as tf
import pdb
import socket
import json
import logging
from player_piece import Player


IMAGE_SIZE = 20


LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)

ch = logging.StreamHandler()
LOG.addHandler(ch)

PIECE_MAPPING = [
    ["101", "a"],
    ["201", "b"],
    ["301", "c"],
    ["302", "d"],
    ["401", "e"],
    ["402", "f"],
    ["403", "g"],
    ["404", "h"],
    ["405", "i"],
    ["501", "j"],
    ["502", "k"],
    ["503", "l"],
    ["504", "m"],
    ["505", "n"],
    ["506", "o"],
    ["507", "p"],
    ["508", "q"],
    ["509", "r"],
    ["510", "s"],
    ["511", "t"],
    ["512", "u"]
]

PIECES = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u"]

np.set_printoptions(linewidth = 100)

class Round:

    def __init__(self):
        self._client_socket = None
        self._player_boards = []        
        self._ai_player = Player()


    def get_piece(self, id):
        for piece_map in PIECE_MAPPING:
            if piece_map[0] == str(id):
                return piece_map[1]

        raise Exception("err")

    def get_piece_name(self, id):
        for piece_map in PIECE_MAPPING:
            if piece_map[1] == id:
                return piece_map[0]

        raise Exception("err")        

    def connect(self, server, port):
        address = (server, port)
        self._client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._client_socket.connect(address)

    def register(self, team_id, team_name):
        data = {}
        data["msg_name"] = "registration"
        data["msg_data"] = {}
        data["msg_data"]["team_id"] = team_id
        data["msg_data"]["team_name"] = team_name

        msg_body = json.dumps(data)
        msg_body = "%05d%s" % (len(msg_body), msg_body)
        self._client_socket.send(msg_body)

        data = self._client_socket.recv(512)
        LOG.info("RECV:%s" % data)

        data_len = data[0:5]
        data_body = data[5:]

    def run(self):
        for i in range(0,4):
            self._player_boards.append(np.full((IMAGE_SIZE, IMAGE_SIZE), "0", dtype = str))
        buf = ""
        pattern = r"\d{5}\{"
        while True:
            msg = self._client_socket.recv(8192)
            LOG.info("RECV:%s" % msg)

            buf = buf + msg

            results = re.findall(pattern, buf)
            for r in results:
                data_len = int(r[0:5])
                header_idx = buf.index(r)
                #00006{abcd e }00007{11111}
                #01234567891011     
                if len(buf) < header_idx + 5 + data_len:
                    break
                data_body = buf[header_idx+5: data_len + header_idx + 5]

                if data_len + header_idx + 5 + 1 < len(buf):
                    buf = buf[data_len + header_idx + 5:]
                else:
                    buf = ""

                rsp = json.loads(data_body)
                if rsp["msg_name"] == "notification":

                    chessman = rsp["msg_data"]["chessman"]
                    player_id = rsp["msg_data"]["player_id"]
                    no = rsp["msg_data"]["hand_no"]

                    if not "id" in chessman:
                        continue
                    piece = self.get_piece(chessman["id"])

                    for sq in chessman["squareness"]:
                        for i in range(0,4):
                            if not player_id == i + 1:
                                self._player_boards[i][19-sq["y"]][sq["x"]] = "1"
                            else:
                                self._player_boards[i][19-sq["y"]][sq["x"]] = piece
                elif rsp["msg_name"] == "inquire":

                    player_id = rsp["msg_data"]["player_id"]
                    team_id = rsp["msg_data"]["team_id"]

                    my_board = self._player_boards[player_id - 1]

                    rotated_board = np.copy(self._player_boards[player_id - 1])
                    if player_id >= 2:
                        rotated_board = np.rot90(rotated_board, player_id - 1)

                    LOG.info("BOARD=>\n%s\n" % (rotated_board))

                    oneline_board = "\\".join(''.join(str(x) for x in y) for y in rotated_board)

                    no = rsp["msg_data"]["hand_no"]

                    possible_base_points = np.argwhere(rotated_board >= 'a')

                    base_points_new_points = []
                    for point in possible_base_points:
                        y = 19 - point[0]
                        x = point[1]

                        new_points = []
                        if 0 <= y + 1 <= 19 and 0 <= x + 1 <= 19 and rotated_board[19-(y+1)][x+1] == "0":
                            new_points.append([x + 1, y + 1])

                        if 0 <= y - 1 <= 19 and 0 <= x + 1 <= 19 and rotated_board[19-(y-1)][x+1] == "0":
                            new_points.append([x + 1, y - 1])

                        if 0 <= y - 1 <= 19 and 0 <= x - 1 <= 19 and rotated_board[19-(y-1)][x-1] == "0":
                            new_points.append([x - 1, y - 1])

                        if 0 <= y + 1 <= 19 and 0 <= x - 1 <= 19 and rotated_board[19-(y+1)][x-1] == "0":
                            new_points.append([x - 1, y + 1])

                        if len(new_points) > 0:
                            for p in new_points:
                                base_points_new_points.append([[x,y],[p[0],p[1]]])


                    if len(base_points_new_points) == 0:
                        base_points_new_points.append([[0,0],[0,0]])
                    
                    res = []
                    for possible_point in base_points_new_points:
                        p, label = self._ai_player.play(oneline_board, int(no == player_id), "%s,%s" % (possible_point[0][0],possible_point[0][1]), "%s,%s" % (possible_point[1][0],possible_point[1][1]), no)                                               
                        if p == 0:
                            continue
                        res.append([p, label])
 
                    if len(res) == 0:
                    	continue

                    res = sorted(res, key = lambda k: [k[0], k[1]],reverse=True)
                    
                    
                    LOG.info("RES  =>%s,%s" % (res[0][0],res[0][1]))
                    determined = res[0]
                    determined_piece = determined[1].split(" ")[0]
                    determined_pos = determined[1].split(" ")[1:]

                    step_points = np.full((IMAGE_SIZE, IMAGE_SIZE), "0", dtype = str)
                    for p in determined_pos:
                        x = int(p.split(",")[0])
                        y = 19 - int(p.split(",")[1])

                        step_points[y][x] = "1"

                    #pdb.set_trace()
                    if player_id >= 2:
                        step_points = np.rot90(step_points, -(player_id - 1))

                    points = np.argwhere(step_points != "0")
                    piece = self.get_piece_name(determined_piece)


                    LOG.info("MB    =>\n%s\n" % (my_board))

                    action = {}
                    action["msg_name"] = "action"
                    action["msg_data"] = {}
                    action["msg_data"]["hand_no"] = no
                    action["msg_data"]["team_id"] = team_id
                    action["msg_data"]["player_id"] = player_id
                    action["msg_data"]["chessman"] = {}
                    action["msg_data"]["chessman"]["id"] = int(piece)
                    action["msg_data"]["chessman"]["squareness"] = []
                    for p in points:
                        action["msg_data"]["chessman"]["squareness"].append({"y":19 - p[0], "x":p[1]})

                    msg_body = json.dumps(action, sort_keys = True).replace(" ", "")

                    msg_body = "%05d%s" % (len(msg_body), msg_body)
                    LOG.info("===>%s" % msg_body)
                    self._client_socket.send(msg_body)



def main():
    LOG.info("start")
    r = Round()
    r.connect("192.168.2.118", 6000)
    r.register(10110, "test")
    r.run()

if __name__ == "__main__":
    main()