import os
import sys
import re

buf = '''
00189{"msg_data":{"chessman":{"id":505,"squareness":[{"x":6,"y":6},{"x":7,"y":6},{"x":7,"y":7},{"x":8,"y":7},{"x":8,"y":8}]},"hand_no":9,"player_id":1,"team_id":2007},"msg_name":"notification"}
00079{"msg_data":{"hand_no":10,"player_id":2,"team_id":10110},"msg_name":"inquire"}
'''
pattern = r"\d{5}\{"

results = re.findall(pattern, buf)
for r in results:
    data_len = int(r[0:5])
    header_idx = buf.index(r)
    #00006{abcd e }00007{11111}
    #01234567891011     
    if len(buf) < header_idx + 5 + data_len:
        break
    data_body = buf[header_idx+5: data_len + header_idx + 5]

    if data_len + header_idx + 5 + 1 < len(buf):
        buf = buf[data_len + header_idx + 5:]
    else:
        buf = ""
    print(header_idx)
    print(data_len)
    print(buf)
    print(data_body)