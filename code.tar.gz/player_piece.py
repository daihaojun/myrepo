from __future__ import print_function

import os
import sys
import fnmatch
import random
import numpy as np
import traceback
import tensorflow as tf
import pdb

import logging
 
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)

ch = logging.StreamHandler()
LOG.addHandler(ch)

TRAIN_DIRECTORY = "./data_train"
VALIDATION_DIRECTORY = "./data_validation"

BATCH_SIZE = 50
IMAGE_SIZE = 20
FEATURE_PLANES = 8
FILTERS = 128
HIDDEN = 12800
LABEL_SIZE = 30433

PIECE_MAPPING = [
    ["101", "a"],
    ["201", "b"],
    ["301", "c"],
    ["302", "d"],
    ["401", "e"],
    ["402", "f"],
    ["403", "g"],
    ["404", "h"],
    ["405", "i"],
    ["501", "j"],
    ["502", "k"],
    ["503", "l"],
    ["504", "m"],
    ["505", "n"],
    ["506", "o"],
    ["507", "p"],
    ["508", "q"],
    ["509", "r"],
    ["510", "s"],
    ["511", "t"],
    ["512", "u"]
]

PIECES = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u"]

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial)


def bias_variable(shape):
    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial)


def conv2d(x, W, stride):
    return tf.nn.conv2d(x, W, strides=[1, stride, stride, 1], padding="SAME")


def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def find_files(directory, pattern):
    '''Recursively finds all files matching the pattern.'''
    files = []
    for root, dirnames, filenames in os.walk(directory):
        for filename in fnmatch.filter(filenames, pattern):
            files.append(os.path.join(root, filename))
    return files

class Player:

    def __init__(self):
        self._train_directory = "./data_train"
        self._validation_directory = "./data_validation"
        self._label_directory = "./labels"
        self._labels = []
        self._label_size = 30433
        self._tf_prediction = None
        self._tf_train_prediction = None
        self._logdir = None
        self._loss = None
        self._sess = None
        self._optimizer = None
        self._saver = None

        self._init_data()

        self._init_tf()

        LOG.info("Training, labels:%s" % (str(self._label_size)))

    def model(self, data):
        # network weights
        W_conv1 = weight_variable([IMAGE_SIZE, IMAGE_SIZE, FEATURE_PLANES, FILTERS])
        b_conv1 = bias_variable([FILTERS])

        W_conv2 = weight_variable([5, 5, FILTERS, FILTERS])
        b_conv2 = bias_variable([FILTERS])

        W_conv3 = weight_variable([3, 3, FILTERS, FILTERS])
        b_conv3 = bias_variable([FILTERS])

        W_fc1 = weight_variable([HIDDEN, HIDDEN])
        b_fc1 = bias_variable([HIDDEN])

        W_fc2 = weight_variable([HIDDEN, LABEL_SIZE])
        b_fc2 = bias_variable([LABEL_SIZE])

        # hidden layers
        h_conv1 = tf.nn.relu(conv2d(data, W_conv1, 1) + b_conv1)
        h_conv2 = tf.nn.relu(conv2d(h_conv1, W_conv2, 1) + b_conv2)
        h_conv3 = tf.nn.relu(conv2d(h_conv2, W_conv3, 1) + b_conv3)
        h_pool3 = max_pool_2x2(h_conv3)
        h_flat = tf.reshape(h_pool3, [-1, HIDDEN])
        h_fc1 = tf.nn.relu(tf.matmul(h_flat, W_fc1) + b_fc1)

        # readout layer
        readout = tf.matmul(h_fc1, W_fc2) + b_fc2
        return readout

    def _init_tf(self):
        
        LOG.info('init tf')

        self._logdir = "logdir"




        self._tf_prediction = tf.placeholder(tf.float32,
                                      shape=(None,
                                      IMAGE_SIZE,
                                      IMAGE_SIZE,
                                      FEATURE_PLANES))


        # Training computation.
        logits = self.model(self._tf_prediction)
        self._tf_train_prediction = tf.nn.softmax(logits)

        
        self._sess = tf.Session()
        self._saver = tf.train.Saver()

        self._sess.run(tf.initialize_all_variables())
        checkpoint = tf.train.get_checkpoint_state(self._logdir)
        if checkpoint and checkpoint.model_checkpoint_path:
            self._saver.restore(self._sess, checkpoint.model_checkpoint_path)
            print ("Successfully loaded:", checkpoint.model_checkpoint_path)

    
    def _init_data(self):
        files = find_files(self._label_directory, "*.txt")

        for filename in files:
            with open(filename) as f:
                 lines = f.readlines()
                 for label in lines:
                     if(label != " " and label != "\n"):
                         self._labels.append(label.replace("\n","").replace("\r",""))
         

    def reformat(self, game,first_step, base_point, new_point, no):
        game_arr = game.split(" ")
        board_state = (game_arr[0]).replace("\\","")

        score = 1
        
        plane_list = []
        plane_list.append(np.reshape([int(-1 if not val == "0" else 0) for val in board_state],(IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.reshape([int(1 if not val == "0" else 0) for val in board_state],(IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), first_step, dtype=int))
        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), score, dtype=int))
        plane_list.append(np.reshape([((ord(val) - 96) / 10. if not val == "1" and not val == "0" else 0) for val in board_state], (IMAGE_SIZE, IMAGE_SIZE)))
        plane_list.append(np.reshape([int(val == "1") for val in board_state], (IMAGE_SIZE, IMAGE_SIZE)))
        plane_hot_points = np.full((IMAGE_SIZE, IMAGE_SIZE), 0, dtype=int)

        x,y = base_point.split(",")
        plane_hot_points[int(y)][int(x)] = 1

        x,y = new_point.split(",")
        plane_hot_points[int(y)][int(x)] = 1        

        plane_list.append(plane_hot_points)

        plane_list.append(np.full((IMAGE_SIZE, IMAGE_SIZE), no / 84))

        planes = np.vstack(tuple(plane_list))
        planes = np.reshape(planes, (1, IMAGE_SIZE, IMAGE_SIZE, FEATURE_PLANES))
        return planes


    def play(self, board_state, first_step, base_point,new_point, no):

        LOG.info("P:%s/%s" % (base_point,new_point))


        game_state = self.reformat(board_state, first_step, base_point, new_point, no)
        feed_dict = {self._tf_prediction: game_state}
        predictions = self._sess.run([self._tf_train_prediction], feed_dict= feed_dict)

        res = []

        for idx ,val in enumerate(predictions[0][0]):
            res.append([val, idx])

        res = sorted(res, key = lambda k: [k[0], k[1]],reverse=True)


        arr = board_state.split(" ")
        oneline_board_state = (arr[0]).replace("\\","")

        board_plane = np.reshape(list(oneline_board_state),(IMAGE_SIZE, IMAGE_SIZE))

        for i in res:
            label = self._labels[i[1]]
            piece = label.split(" ")[0]
            #LOG.info("\tL:%s,%s" % (i[0],label))
            if self.is_legal_move(board_state, board_plane, new_point, label):
                LOG.info("\tL:%s,%s=>OK" % (i[0],label))
                return i[0], label
            #else:
                #LOG.info("\tL:%s,%s=>NG" % (i[0],label))
            #else:
            #    LOG.info("ILL:%s" % label)

        return 0, ""

    def is_legal_move(self, board_state, board_plane, new_point, label):

        #pdb.set_trace()
        

        piece = label.split(" ")[0]
        if piece in board_state:
            #LOG.info("\t\tE:piece used")
            return False

        found = False
        points = label.split(" ")[1:]
        for p in points:
            if new_point == p:
                found = True
                break

        if not found:
            #LOG.info("\t\tE:no valid point")
            return False

        neighbor_count = 0
        for pos in label.split(" ")[1:]:
            #LOG.info("\t\ttesting pos:%s" % pos)
            x,y = pos.split(",")
            x = int(x)
            y = 19 - int(y)
            if board_plane[y][x] != "0":
                #LOG.info("\t\t\tE:overlap")
                return False


            neighbors = [[x+1,y+1],[x-1,y-1],[x+1,y-1],[x-1,y+1]]

            for neighbor in neighbors:
                if neighbor[0] >= 0 and neighbor[0] <= 19 and neighbor[1] >= 0 and neighbor[1] <= 19:
                    if board_plane[neighbor[1]][neighbor[0]] in PIECES:
                        #LOG.info("\t\t\t\tN:%s,%s:%s" % (neighbor[0], neighbor[1], board_plane[neighbor[1]][neighbor[0]]))
                        neighbor_count = neighbor_count + 1
                        break

            if neighbor_count > 1:
                #LOG.info("\t\t\tE:multi nb:%s" % label)
                return False

            neighbors = [[x+1,y],[x-1,y],[x,y-1],[x,y+1]]
            for neighbor in neighbors:
                if neighbor[0] >= 0 and neighbor[0] <= 19 and neighbor[1] >= 0 and neighbor[1] <= 19:
                    if board_plane[neighbor[1]][neighbor[0]] in PIECES:
                        #LOG.info("\t\t\tE:illegal:%s" % label)
                        return False
        return True