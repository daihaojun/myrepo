import os
import sys
import pdb
import json

import numpy as np

PIECE_MAPPING = [
	["101", "a", ["x"], 					400],
	["201", "b", ["xx"], 					760],
	["301", "c", ["xxx"], 					720],
	["302", "d", ["x.", "xx"],				1444],
	["401", "e", ["xxxx"], 					680],
	["402", "f", [".x.", "xxx"],			1368],
	["403", "g", [".xx", "xx."],			1368],
	["404", "h", ["x..", "xxx"],    		2736],
	["405", "i", ["xx", "xx"],				361],
	["501", "j", ["xxxxx"],          		640],
	["502", "k", [".x.", ".x.", "xxx"], 	1296],
	["503", "l", [".x.", "xxx", ".x."],		324],
	["504", "m", ["x..", "x..", "xxx"],		1296],
	["505", "n", ["x..", "xx.", ".xx"],		1296],
	["506", "o", ["xx.", "xxx"],			2736],
	["507", "p", [".x..", "xxxx"],			2584],
	["508", "q", ["x...", "xxxx"],          2584],
	["509", "r", ["x.x", "xxx"],            1368],
	["510", "s", ["xxx.", "..xx"],          2584],
	["511", "t", [".xx",".x.", "xx."],      1286],
	["512", "u", [".x.","xxx", "x.."], 		2592]
]

all_pos = {}

for item in PIECE_MAPPING:
	shape_txt = item[2]
	wide = len(shape_txt[0])
	high = len(shape_txt)
	all_pos[item[1]] = []
	rect = np.full((high, wide), 0, dtype = int)
	for hidx, hval in enumerate(shape_txt):
		for widx, wval in enumerate(list(hval)):
			if wval == "x":
				rect[hidx][widx] = 1

	temp = []
	for bh in range(0,20):
		for bw in range(0,20):
			if high + bh - 1 > 19 or wide + bw - 1 > 19:
				break
			board = np.full((20,20), 0, dtype = int)
			for h in range(0, high):
				for w in range(0, wide):
					board[h + bh][w + bw] = rect[h][w]

			for ang in range(0, 4):
				new_board = np.copy(board)
				new_board = np.rot90(new_board, ang)
				points = np.argwhere(new_board > 0)
				temp.append(points)
				new_board_lr = np.fliplr(new_board)
				points = np.argwhere(new_board_lr > 0)
				temp.append(points)

				new_board_ud = np.flipud(new_board)
				points = np.argwhere(new_board_ud > 0)
				temp.append(points)


	for t in temp:
		found = False
		for e in all_pos[item[1]]:
			if np.array_equal(t,e):
				found = True
				break
		if not found:
			all_pos[item[1]].append(t)

c = 0
for k,v in all_pos.iteritems():
	for points in v:
		arr = []
		for p in points:
			arr.append([p[1], p[0]])
		arr = sorted(arr, key = lambda k: [k[0], k[1]])
		arr1 = []
		for a in arr:
			arr1.append("%s,%s" % (a[0], a[1]))
		print "%s %s" % (k," ".join(arr1))




